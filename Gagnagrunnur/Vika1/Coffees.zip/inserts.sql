INSERT INTO coffees VALUES ('mareland', 'Nescaffee');
INSERT INTO coffeehouses VALUES ('The little house', 'Sudurlandsbraut 20', 'Coffee Licence');
