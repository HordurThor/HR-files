from wordle import Wordle

def main():
    wordle = Wordle()
    wordle.run_program()



if __name__ == '__main__':
    main()